var scenes	=	[
				"Go Intro",
				"Fade Out Intro",
				"Freeze Cam",
				"Unfreeze Cam + Fade",
				"Fade Cam /  Movie",
				"Fade Out / Go Music"
]